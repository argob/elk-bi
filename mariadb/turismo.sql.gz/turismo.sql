-- MySQL dump 10.16  Distrib 10.1.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: turismo
-- ------------------------------------------------------
-- Server version	10.1.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ciudades`
--

DROP TABLE IF EXISTS `ciudades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ciudades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provincia_id` int(11) DEFAULT NULL,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `province_id` (`provincia_id`),
  CONSTRAINT `ciudades_ibfk_1` FOREIGN KEY (`provincia_id`) REFERENCES `provincias` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ciudades`
--

LOCK TABLES `ciudades` WRITE;
/*!40000 ALTER TABLE `ciudades` DISABLE KEYS */;
INSERT INTO `ciudades` VALUES (1,7,'CABA'),(2,2,'PUERTO MADRYN'),(3,3,'POSADAS'),(4,5,'ROSARIO'),(5,1,'MAR DEL PLATA'),(6,1,'VILLA GESSEL'),(7,3,'PUERTO IGUAZÚ'),(8,6,'GUALEGUAYCHÚ'),(9,8,'SAN MARTÍN DE LOS ANDES'),(10,9,'TALAMPAYA');
/*!40000 ALTER TABLE `ciudades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lugares`
--

DROP TABLE IF EXISTS `lugares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lugares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `categoria` int(11) DEFAULT NULL,
  `region` int(11) NOT NULL,
  `provincia` int(11) NOT NULL,
  `ciudad` int(11) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `web` varchar(60) DEFAULT NULL,
  `creado` datetime NOT NULL,
  `modificado` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lugares`
--

LOCK TABLES `lugares` WRITE;
/*!40000 ALTER TABLE `lugares` DISABLE KEYS */;
INSERT INTO `lugares` VALUES (1,1,'HOTEL COSTA GALANA',5,1,1,5,'Peralta Ramos 5725, Playa Grande',-38.027596,-57.533965,'(0223) 410-5000','reservas@hotelcostagalana.com','www.hotelcostagalana.com','2017-06-17 14:08:00','2017-06-17 14:08:00'),(2,2,'BALNEARIO NOCTILUCA',NULL,1,1,6,'Paseo 126 y Playa',-37.2792017,-56.9814393,'(02255) 46-3072',NULL,NULL,'2017-06-17 14:09:02','2017-06-17 14:09:02'),(3,6,'RESTAURANTE EL ALMENDRO',NULL,5,2,2,'Marcelo T. de Alvear 409',-42.7704511,-65.0402836,'(0280) 447-0525',NULL,' http://elalmendro.ucoz.com/','2017-06-17 18:14:51','2017-06-17 18:14:51'),(4,3,'PARQUE NACIONAL IGUAZÚ',NULL,6,3,7,'Ruta 101 Km 142',-25.683119,-54.454765,'(03757) 491469','info@iguazuargentina.com',' www.iguazuargentina.com','2017-06-17 18:55:45','2017-06-17 18:55:45'),(5,1,'IMAGINE HOTEL BOUTIQUE',4,1,1,1,'México 1330',-34.615483,-58.384949,'(0223) 410-5000',NULL,NULL,'2017-06-17 14:08:00','2017-06-19 19:39:55'),(6,1,'HOTEL GUALEGUAYCHÚ',3,6,6,8,'Calle 2 1992',-38.027596,-56.533965,'(011) 5354-2374',NULL,NULL,'2017-06-17 14:08:00','2017-06-21 19:39:55'),(7,2,'BALNEARIO PUNTA IGLESIA',NULL,1,1,5,'Bv. Marítimo y Diagonal Alberti',-38.020081,-57.526268,'(0223) 494-5608',NULL,NULL,'2017-06-28 14:39:13','2017-06-28 14:39:13'),(8,8,'CABAÑAS LAS PAMPAS',3,5,8,9,'Almirante Brown 333',-40.162073,-71.355309,'(02972) 423-783','laspampas@smandes.com.ar','www.cablaspampas.com.ar','2017-06-28 14:39:13','2017-06-28 14:39:13'),(9,9,'PARQUE NACIONAL TALAMPAYA',NULL,3,9,10,'RN 150, Km. 144',-30.205099,-67.294167,'(03825) 47-0356',NULL,NULL,'2017-06-28 14:39:13','2017-06-28 14:39:13');
/*!40000 ALTER TABLE `lugares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `lugares_resueltos`
--

DROP TABLE IF EXISTS `lugares_resueltos`;
/*!50001 DROP VIEW IF EXISTS `lugares_resueltos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `lugares_resueltos` (
  `id` tinyint NOT NULL,
  `tipo` tinyint NOT NULL,
  `nombre` tinyint NOT NULL,
  `categoria` tinyint NOT NULL,
  `region` tinyint NOT NULL,
  `provincia` tinyint NOT NULL,
  `ciudad` tinyint NOT NULL,
  `direccion` tinyint NOT NULL,
  `lat` tinyint NOT NULL,
  `lon` tinyint NOT NULL,
  `telefono` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `web` tinyint NOT NULL,
  `creado` tinyint NOT NULL,
  `modificado` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `provincias`
--

DROP TABLE IF EXISTS `provincias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provincias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) DEFAULT NULL,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `region_id` (`region_id`),
  CONSTRAINT `provincias_ibfk_1` FOREIGN KEY (`region_id`) REFERENCES `regiones` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provincias`
--

LOCK TABLES `provincias` WRITE;
/*!40000 ALTER TABLE `provincias` DISABLE KEYS */;
INSERT INTO `provincias` VALUES (1,1,'BUENOS AIRES'),(2,5,'CHUBUT'),(3,6,'MISIONES'),(4,4,'JUJUY'),(5,2,'SANTA FÉ'),(6,6,'ENTRE RÍOS'),(7,1,'CABA'),(8,5,'NEUQUÉN'),(9,3,'LA RIOJA');
/*!40000 ALTER TABLE `provincias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regiones`
--

DROP TABLE IF EXISTS `regiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regiones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regiones`
--

LOCK TABLES `regiones` WRITE;
/*!40000 ALTER TABLE `regiones` DISABLE KEYS */;
INSERT INTO `regiones` VALUES (1,'BUENOS AIRES'),(2,'CENTRO'),(3,'CUYO'),(4,'NOA'),(5,'PATAGONIA'),(6,'LITORAL');
/*!40000 ALTER TABLE `regiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_lugar`
--

DROP TABLE IF EXISTS `tipos_lugar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos_lugar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_lugar`
--

LOCK TABLES `tipos_lugar` WRITE;
/*!40000 ALTER TABLE `tipos_lugar` DISABLE KEYS */;
INSERT INTO `tipos_lugar` VALUES (1,'HOTEL'),(2,'BALNEARIO'),(3,'ÁREA NATURAL'),(4,'ESPACIO CULTURAL'),(5,'OFICINA DE INFORMES'),(6,'GASTRONOMÍA'),(7,'SERVICIO TURÍSTICO'),(8,'CABAÑAS'),(9,'PARQUE NACIONAL');
/*!40000 ALTER TABLE `tipos_lugar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `lugares_resueltos`
--

/*!50001 DROP TABLE IF EXISTS `lugares_resueltos`*/;
/*!50001 DROP VIEW IF EXISTS `lugares_resueltos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lugares_resueltos` AS select `lugares`.`id` AS `id`,`t`.`descripcion` AS `tipo`,`lugares`.`nombre` AS `nombre`,`lugares`.`categoria` AS `categoria`,`r`.`descripcion` AS `region`,`p`.`descripcion` AS `provincia`,`c`.`descripcion` AS `ciudad`,`lugares`.`direccion` AS `direccion`,`lugares`.`lat` AS `lat`,`lugares`.`lon` AS `lon`,`lugares`.`telefono` AS `telefono`,`lugares`.`email` AS `email`,`lugares`.`web` AS `web`,`lugares`.`creado` AS `creado`,`lugares`.`modificado` AS `modificado` from ((((`lugares` left join `tipos_lugar` `t` on((`lugares`.`tipo` = `t`.`id`))) left join `regiones` `r` on((`lugares`.`region` = `r`.`id`))) left join `provincias` `p` on((`lugares`.`provincia` = `p`.`id`))) left join `ciudades` `c` on((`lugares`.`ciudad` = `c`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-29 13:42:04
